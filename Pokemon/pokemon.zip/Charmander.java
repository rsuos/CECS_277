import java.util.Random;

/**
 *Charmander is a fire type pokemon that inherits the Pokemon class and extends the fire interface
 */
public class Charmander extends Pokemon implements Fire
{
  /**
  * Default constructor for Charmander
  */
  Charmander()
  {
    super("Charmander");
  }

  /**
  * Dispalys special attack menu of fire type pokemons
  @return Return the special attack menu as a String
  */
  @Override
  public String getSpecialMenu()
  {
    return Fire.specialMenu;
  }
  
  /**
  * Gets the amount of special menu items as an integer
  *@return Returns the number of special menu items as an int
  */
  @Override
  public int getNumSpecialMenuItems()
  {
	  return Fire.numSpecialMenuItems;
  }
  
  /**
  * Implements the special attack menu on another Pokemon
  *@param P opponent Pokemon to receieve damage
  *@param move the type of special attack to be performed on Pokemon P
  *@return battleDescription returns what battle attack and damage has been occured
  */
  @Override
  public String specialAttack(Pokemon p, int move)
  {
	  String battleDescription = "";
	  
	  switch (move)
	  {
	  case 1:
		  battleDescription += ember(p);
		  break;
	  case 2: 
		  battleDescription += fireBlast(p);
		  break;
	  case 3:
		  battleDescription += firePunch(p);
		  break;
	  }
	  
	  return battleDescription;
  }

  /**
  * Current Pokemon uses ember on opponent Pokemon
  * @param p Pokemon to take ember damage
  * @return returns the opponent Pokemons name and attack damage as a String
  */
  @Override
  public String ember(Pokemon p)
  {
	  // 0 - 3 Damage
	  Random r = new Random();
	  int battleDamage = r.nextInt(4);
	  double typeMatchUp = battleTable[this.getType()][p.getType()];
	  int totalDamage = (int)(typeMatchUp * battleDamage);
	  p.takeDamage(totalDamage);
	  
	  return p.getName() + " is immolated with a strong,burning EMBER and takes " + totalDamage + " damage.";
  }

    /**
  * Current Pokemon uses Fire Blast on opponent Pokemon
  * @param p Pokemon to take Fire Blast damage
  * @return returns the opponent Pokemons name and attack damage as a String
  */
  @Override
  public String fireBlast(Pokemon p)
  {

	  // 1 - 4 Damage
	  Random r = new Random();
	  int battleDamage = r.nextInt(4) + 1;
	  double typeMatchUp = battleTable[this.getType()][p.getType()];
	  int totalDamage = (int)(typeMatchUp * battleDamage);
	  p.takeDamage(totalDamage);
	  
	  return p.getName() + " is absolutely BLASTED with FIRE and takes " + totalDamage + " damage.";
  }

    /**
  * Current Pokemon uses ember on opponent Pokemon
  * @param p Pokemon to take ember damage
  * @return returns the opponent Pokemons name and attack damage as a String
  */
  @Override
  public String firePunch(Pokemon p)
  {
	  // 1 - 3 Damage
	  Random r = new Random();
	  int battleDamage = r.nextInt(3) + 1;
	  double typeMatchUp = battleTable[this.getType()][p.getType()];
	  int totalDamage = (int)(typeMatchUp * battleDamage);
	  p.takeDamage(totalDamage);
	  
	  return p.getName() + " is PUNCHED by FIERY fist and takes " + totalDamage + " damage.";
  }
}