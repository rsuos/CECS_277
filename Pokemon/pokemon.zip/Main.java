class Main {
  public static void main(String[] args) {

	String playerName;
		  
	int firstPokemonChoice;

  int randomDirection = 0;
		  
	Pokemon firstPokemon = null;
		  
	Map playerMap = new Map();
		  
	System.out.println("Prof. Oak: Hello there new trainer, what is your name?");
		  
	playerName = CheckInput.getString();
		  
	System.out.println("Great to meet you, " + playerName);
		  
	System.out.println("Choose your first pokemon:\n1. Charmander\n2. Bulbasaur\n3. Squirtle");
		  
	firstPokemonChoice = CheckInput.getIntRange(1, 3);
		  
	switch(firstPokemonChoice)	{
		case 1: firstPokemon = new Charmander();
		  		break;
		case 2: firstPokemon = new Bulbasaur();
		  		break;
		case 3: firstPokemon = new Squirtle();
		  		break;
		  }
	
  playerMap.loadMap(1);
	Trainer player = new Trainer(playerName, firstPokemon, playerMap);
	
	
	Boolean playingGame = true;
	
	while (playingGame)
	{
    	if (player.getHp() == 0)
    	{
        System.out.println("Game over.");
        break;
      }
      
      	int mapNumber = 1;
      	
      	System.out.println(player.toString());
      	
      	System.out.println("Map:\n" + playerMap.mapToString(player.getLocation()));
      	
	switch (mainMenu())		{	// Returns an int value that determines methods to be called upon
		case 1: 
				player.goNorth();
				if (playerMap.getCharAtLoc(player.getLocation()) == 'e')
				{
          			System.out.println("You cannot go that way.\n");
          			player.goSouth();         
        		}
				break;
		case 2: 
				player.goSouth();
				if (playerMap.getCharAtLoc(player.getLocation()) == 'e')
				{
          			System.out.println("You cannot go that way.\n");
          			player.goNorth(); 
          		}
				break;
		case 3: 
				player.goEast();
				if (playerMap.getCharAtLoc(player.getLocation()) == 'e')
				{
          			System.out.println("You cannot go that way.\n");
          			player.goWest();
          		} 
				break;
		case 4: 
				player.goWest();
				if (playerMap.getCharAtLoc(player.getLocation()) == 'e')
				{
          			System.out.println("You cannot go that way.\n");
          			player.goEast(); 
          		}
				break;
		case 5: playingGame = false;
        System.out.println("Thank you for playing!");
				break;				
		}
		
		if (playingGame == false) break;
		
		switch (playerMap.getCharAtLoc(player.getLocation()))
		{
      		case 'f':

      			switch (mapNumber)
      			{
              		case 1:
              			playerMap.loadMap(2);
              			mapNumber = 2;
              			break;
              		case 2:
              			playerMap.loadMap(3);
              			mapNumber = 3;
              			break;
              		case 3:
              			playerMap.loadMap(1);
              			mapNumber = 1;
              			break;
            	}

              System.out.println("You've found the next map!\nLoading map #" + mapNumber);
      			break;
      		case 'n': {
            System.out.println("There's nothing here...");
            break;
          }
      		case 'i':
      			int item = RandomNumberGenerator.RandomNumberInRange(1, 2);
      			if (item == 1) 
      			{
             	System.out.println("You have received a Pokeball!");
              	player.receivePokeball();
            	}
            	if (item == 2)
            	{
                System.out.println("You have received a Potion!");
                player.receivePotion();
              	}
      			playerMap.removeCharAtLoc(player.getLocation());
      			break;
      		case 'w':
      			// Wild pokemon encounter

            Pokemon wildPokemon = chooseRandomPokemon();

            System.out.println("A wild " + wildPokemon.getName() + " has appeared!\n");

            boolean battle = true;

            boolean pokemonCaught = false;

            // Boolean to determine if character should be removed.
            // if true, character is removed from player position.
            // if false, w character remains in player position.
            boolean playerWins = false; 
            
            while (battle)
            {
              int battleChoice = 0;

              if (wildPokemon.getHp() == 0 || player.getHp() == 0 || pokemonCaught) {
                battle = false;
                playerWins = true;
              }

              if(playerWins)  {
              playerMap.removeCharAtLoc(player.getLocation());
              }

              if (battle == false) break;

              // System.out.println(wildPokemon.getName() + " HP: " + wildPokemon.getHp() + "/" + wildPokemon.getMaxHp());

              System.out.println("\n" + wildPokemon.toString());

              System.out.println("What do you want to do?\n1. Fight\n2. Use Potion\n3. Throw Poke Ball\n4. Run Away ");
              
              battleChoice = CheckInput.getIntRange(1,4);

              switch (battleChoice)
              {
                case 1: // Fight
                  boolean allDead = false;
                  
                  
                  for (int i = 1; i <= player.getNumPokemon(); i++)
                  { 
                    Pokemon currentPokemon = player.getPokemon(i);
                    if (currentPokemon.getHp() == 0) allDead = true;
                    if (currentPokemon.getHp() > 0)
                    {
                      allDead = false;
                      break;
                    }
                  }
                  if (allDead == true)
                  {
                    System.out.println("All your Pokemon are unable to battle\nYou took some damage from " + wildPokemon.getName() + "!");
                    player.takeDamage(RandomNumberGenerator.RandomNumberInRange(1, 5));
                    battle = false;
                    System.out.println("You ran away in fear.\n");
                  }
                  else 
                  {
                  trainerAttack(player, wildPokemon);
                  }

                break;
                case 2: // Use Potion
                System.out.println("Choose one of your Pokemon to heal.");
                System.out.println(player.getPokemonList());
                
                int healChoice = CheckInput.getIntRange(1, player.getNumPokemon());
                
                if (player.getPokemon(healChoice).getHp() == player.getPokemon(healChoice).getMaxHp())
                {
                  System.out.println(player.getPokemon(healChoice).getName() + " is already at full health!");
                }
                else if (player.getPokemon(healChoice).getHp() < player.getPokemon(healChoice).getMaxHp())
                {
                  player.usePotion(healChoice);
                  System.out.println(player.getPokemon(healChoice).getName() + " has been healed by a potion.");
                }
                break;
                case 3: // Throw Poke Ball
                  pokemonCaught = player.catchPokemon(wildPokemon);

                  if(pokemonCaught == true) {
                    playerMap.removeCharAtLoc(player.getLocation());
                    battle = false;
                  }

                  break;
                case 4: // Run away
                randomDirection = RandomNumberGenerator.RandomNumberInRange(1, 4);
                battle = false;

                switch(randomDirection) { // Moves the player in a random direction after running away
                  case 1: player.goNorth();
                          break;
                  case 2: player.goSouth();
                          break;
                  case 3: player.goEast();
                          break;
                  case 4: player.goWest();
                          break;
                }
                break;
              }
        
            }
      			break;
      		case 'p':
            int person = RandomNumberGenerator.RandomNumberInRange(1, 5);

            playerMap.removeCharAtLoc(player.getLocation());

            switch (person)
            {
              case 1:
              System.out.println("Brock: I can see that you love Pokemon. Here's a potion!");
              player.receivePotion();
              break;
              case 2:
              System.out.println("Misty: How dare you look at me!\n You took 3 damage!");
              player.takeDamage(3);
              break;
              case 3:
              System.out.println("Gary: Looks like you're as broke as ever heres $10 loser.");
              player.receiveMoney(10);
              break;
              case 4:
              System.out.println("Team Rocket: Take this!\nYou took 5 damage!");
              player.takeDamage(5);
              break;
              case 5:
              System.out.println("Trainer: You might need this on your adventure.\nYou have received a PokeBall!");
              player.receivePokeball();
              break;
            }

      			break;

      		case 'c':
            System.out.println("You have entered a PokeTown!\n Would you like to go to a:\n1) PokeCenter\n2) Store");
            int cityChoice = CheckInput.getIntRange(1, 2);
            switch (cityChoice)
            {
              case 1:
              System.out.println("Thank you for visiting the PokeCenter! All your Pokemon have been healed!");
              player.healAllPokemon();
              break;
              case 2:
              store(player);
              break;
            }
      			break;
        
      	}
      
    
  	}
	  
  }
  
  
  // John
  /**
   * Chooses a random pokemon from all six pokemon available
   * @Pokemon is the random pokemon initialized
   */
  public static Pokemon chooseRandomPokemon() {
	
	Pokemon randomPokemon = null;
    
    int randomChoice = RandomNumberGenerator.RandomNumberInRange(1,6);
	  
	  switch (randomChoice)	{
	  	case 1:	randomPokemon = new Charmander();
	  			break;
	  	case 2:	randomPokemon = new Ponyta();
			    break;
	  	case 3:	randomPokemon = new Squirtle();
			    break;
	  	case 4:	randomPokemon = new Staryu();
			    break;
	  	case 5:	randomPokemon = new Bulbasaur();
			    break;
	  	case 6:	randomPokemon = new Oddish();
			    break;
	  }
    
    return randomPokemon;
  }
  
  /**
   * Displays the main menu choice to the user
   * @return the users menu choice entered
   */
  public static int mainMenu()	{
	int mainMenuChoice;
	
	System.out.printf("%s\n%s\n%s\n%s\n%s\n%s\n","Main Menu:", "1. Go North", "2. Go South", "3. Go East", "4. Go West", "5. Quit");
	
	mainMenuChoice = CheckInput.getIntRange(1,5);
	
	return mainMenuChoice;
  }

  /**
   * Combat between the trainer/trainer's pokemon and the wild pokemon
   * @param t is the trainer
   * @param wild is the wild pokemon encountered
   */
   public static void trainerAttack(Trainer player, Pokemon wildPokemon)	{
     int chosenPokemon = 0;
	   int attackMenuChoice = 0;
     int moveChoice = 0;
     // Wild variables will eventually be randomized to let opposing pokemon attack back
     int wildAttackMenuChoice = 0;
     int wildMoveChoice = 0;

    System.out.println("Choose a pokemon:");
                  
    System.out.println(player.getPokemonList());

    chosenPokemon = CheckInput.getIntRange(1, player.getNumPokemon());
                  
    Pokemon currentPokemon = player.getPokemon(chosenPokemon); // This is a shallow copy. Any changes made to currentPokemon will be applied to the chosenPokemon from the arrayList
    
    System.out.println(currentPokemon.getName() + ", I choose you!\n");

    System.out.println(currentPokemon.getAttackMenu() + "\n");

    attackMenuChoice = CheckInput.getIntRange(1, 2);
    
    switch(attackMenuChoice)  {
    case 1: System.out.println(currentPokemon.getBasicMenu() + "\n");
            moveChoice = CheckInput.getIntRange(1,3);
            System.out.println(currentPokemon.basicAttack(wildPokemon, moveChoice));

            // Wild pokemon attack turn
            wildAttackMenuChoice = RandomNumberGenerator.RandomNumberInRange(1,2);
            wildMoveChoice = RandomNumberGenerator.RandomNumberInRange(1,3);

            if(wildAttackMenuChoice == 1)  {
              System.out.println(wildPokemon.basicAttack(currentPokemon, wildMoveChoice));
            }

            else if(wildAttackMenuChoice == 2)  {
                System.out.println(wildPokemon.specialAttack(currentPokemon, wildMoveChoice));
            }

          break;
      case 2: System.out.println(currentPokemon.getSpecialMenu() + "\n");
              moveChoice = CheckInput.getIntRange(1,3);
              System.out.println(currentPokemon.specialAttack(wildPokemon, moveChoice));

              // Wild pokemon attack turn
              wildAttackMenuChoice = RandomNumberGenerator.RandomNumberInRange(1,2);
              wildMoveChoice = RandomNumberGenerator.RandomNumberInRange(1,3);

              if(wildAttackMenuChoice == 1)  {
                System.out.println(wildPokemon.basicAttack(currentPokemon, wildMoveChoice));
              }

              else if(wildAttackMenuChoice == 2)  {
                System.out.println(wildPokemon.specialAttack(currentPokemon, wildMoveChoice));
              }
      }
    if (currentPokemon.getHp() == 0) System.out.println(currentPokemon.getName() + " has fainted!");

   }
  
  
  /**
   * Displays the store options for the trainer
   * @param t is the trainer
   */
   public static void store(Trainer t)  {
     int storeChoice = 0;

     while(storeChoice != 3)  {
       System.out.printf("%s\n%s\n%s\n%s\n","Hello! What can I help you with?", "1. Buy Potions - $5", "2. Buy Poke Balls - $3", "3. Exit");

       storeChoice = CheckInput.getInt();

       switch(storeChoice)  {
         case 1: if(t.spendMoney(5)) {
                  t.receivePotion();
                  System.out.println("Here's your potion.");
                 }
         		else	{
         			System.out.println("Hey! You don't have enough to pay for this! Get outta here! *Sigh* Deep breaths, think good thoughts. . .");
         		}
                 break;

         case 2: if(t.spendMoney(3)) {
                  t.receivePokeball();
                  System.out.println("Here's your pokeball.");
                 }
         		 else	{
         			 System.out.println("What are you pokebroke?! Get outta here!");
         		 }
                 break;
         case 3: { 
           System.out.println("Thank you! come again soon!\n");
           break;
         }
       }
     }
   }
}