import java.util.Random;

/**
* An abstract class to be extended to specific Pokemon classes
*/
public abstract class Pokemon extends Entity
{
  /**
  * Battle table that determines the total amount of damage being applied to from attacking pokemon to the Pokemon receiving the attack by their type
  */
  static final double [][] battleTable = {{1, .5, 2}, {2,1,.5}, {.5, 2, 1}};

  /**
  * Constructor for Pokemon
  * @param String n is the name of the Pokemon 
  * @param maxHP constructs the max HP of the Pokemon
  */
  public Pokemon(String n, int maxHp)
  {
    super(n, maxHp);
  }

  /**
  * Constructor for Pokemon 
  * @param String n is the name of the Pokemon
  */
  public Pokemon(String n)
  {
    super(n);
  }

  /**
  * Abstract class to be implemented in specific Pokemon classes
  * Returns a String of the special attacks available for a Pokemon depending on its type
  */
  abstract String getSpecialMenu();

  /**
  * Abstract class to be implemented in specific Pokemon classes
  * Returns the number of special attacks as an integer
  */
  abstract int getNumSpecialMenuItems();

    /**
  * Abstract class to be implemented in specific Pokemon classes
  * @param Pokemon p Pokemon being attacked
  * @param int move the move being done to the opposing pokemon
  * Returns a String of a special attack being done on an opposing Pokemon
  */
  abstract String specialAttack(Pokemon p, int move);

  /**
  * Displays the basic attacks that is used by all Pokemons
  * @return returns the basic attack options as a String
  */
  public String getBasicMenu()
  {
    String basicMenu = "1. Slam\n2. Tackle\n3. Punch";

    return basicMenu;
  }

  /**
  * The number of basic attack options
  * @return returns the number of basic attack options as an integer
  */
  public int getNumBasicMenuItems()
  {
    return 3;
  }

  /**
  * Basic attack being done to an opposing Pokemon 
  * @param Pokemon p is the Pokemon being attack 
  * @param int move is the basic attack being done to the opposing pokemon 
  * @return returns the attack and damage done to the opposing Pokemon as a String
  */
  public String basicAttack(Pokemon p, int move)
  {
    String battleDescription = "";
    
    switch (move)
    {
    case 1:
    	battleDescription += slam(p);
    	break;
    case 2:
    	battleDescription += tackle(p);
    	break;
    case 3:
    	battleDescription += punch(p);
    	break;
    }
    
    return battleDescription;
  }

  /**
  * Menu to let the player choose between basic attacks and special attacks 
  * @return returns the options of type of attacks as a String
  */
  public String getAttackMenu()
  {
    return "1. Basic Attacks\n2. Special Attacks";
  }

  /**
  * The number of attack menus 
  * @returns the number of different kinds of attack menus as an integer
  */
  public int getNumAttackMenuItems()
  {
    return 2;
  }

  /**
  * Uses the basic attack Slam on an opposing Pokemon 
  * @param Pokemon p the opposing pokemon receiving the attack 
  * @return returns the attack and damage to the opposing Pokemon as a String
  */
  public String slam(Pokemon p)
  {
	  // 0 - 5 Damage
    Random r = new Random();
    int battleDamage = r.nextInt(6);
	p.takeDamage(battleDamage);
	  
	return p.getName() + " is body SLAMMED and takes " + battleDamage + " damage.";
  }

  /**
  * Uses the basic attack Tackle on an opposing Pokemon 
  * @param Pokemon p the opposing pokemon receiving the attack 
  * @return returns the attack and damage to the opposing Pokemon as a String
  */
  public String tackle(Pokemon p)
  {
    // 2 - 3 Damage
	  Random r = new Random();
	  int battleDamage = r.nextInt(2) + 2;
	  p.takeDamage(battleDamage);
		  
	  return p.getName() + " is TACKLED to the ground and takes  " + battleDamage + " damage.";
  }

  /**
  * Uses the basic attack Punch on an opposing Pokemon 
  * @param Pokemon p the opposing pokemon receiving the attack 
  * @return returns the attack and damage to the opposing Pokemon as a String
  */
  public String punch(Pokemon p)
  {
    // 1 - 4 Damage
	  Random r = new Random();
	  int battleDamage = r.nextInt(4) + 1;
	  p.takeDamage(battleDamage);
		  
	  return p.getName() + " eats a hail of PUNCHES and takes " + battleDamage + " damage.";
  }

  /**
  * Gets the element type of a Pokemon so the battle table can be implemented 
  * @return returns the type of Pokemon the Pokemon is as an integer
  */
  public int getType()
  {
	  int type = 0;
	  
	  if (this instanceof Fire) type = 0;
	  if (this instanceof Water) type = 1;
	  if (this instanceof Grass) type = 2;
     
    return type;
  }

}