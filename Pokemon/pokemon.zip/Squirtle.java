import java.util.Random;

/**
 * Squirtle is a water type pokemon that inherits the Pokemon class and extends the water interface
 */
public class Squirtle extends Pokemon implements Water {
	/**
	   * Default Constructor
	   */
	  public Squirtle() {
	    super("Squirtle");
	  }

	  // Implementation methods of the Water interface
	  
	  /**
	   * Drenches the opposing pokemon with a water gun attack
	   * @param p represents the opposing pokemon
	   * @return the description of the battle between the two pokemon
	   */
	  public String waterGun(Pokemon p)  {
	    // 2 - 5 dmg
		  Random r = new Random();
      int battleDamage = r.nextInt(4) + 2;
      double typeMatchUp = battleTable[this.getType()][p.getType()];
      int totalDamage = (int)(typeMatchUp * battleDamage);
      p.takeDamage(totalDamage);
		  
		  // Return battle description 
		  return  p.getName() +  " is drenched with a WATER GUN and takes " + totalDamage + " damage.";
		
	  }
	  
	  /**
	   * Envelops the opposing pokemon with bubble beam
	   * @param p represents the opposing pokemon
	   * @return the description of the battle between the two pokemon
	   */
	  public String bubbleBeam(Pokemon p)  {
	    // 1-3 dmg
		  Random r = new Random();
      int battleDamage = r.nextInt(3) + 1;
      double typeMatchUp = battleTable[this.getType()][p.getType()];
      int totalDamage = (int)(typeMatchUp * battleDamage);
      p.takeDamage(totalDamage);
		  
		  // Return battle description 
		  return p.getName() +  " is waterboarded by a BEAM of BUBBLES and takes " + totalDamage + " damage.";
	  }
	  
	  /**
	   * Drowns the opposing pokemon in a waterfall
	   * @param p represents the opposing pokemon
	   * @return the description of the battle between the two pokemon
	   */
	  public String waterfall(Pokemon p)  {
	    // 1-4 dmg
		  Random r = new Random();
      int battleDamage = r.nextInt(4) + 1;
      double typeMatchUp = battleTable[this.getType()][p.getType()];
      int totalDamage = (int)(typeMatchUp * battleDamage);
      p.takeDamage(totalDamage); 
		  
		  // Return battle description 
		  return p.getName() +  " is drowned by a rushing WATERFALL and takes " + totalDamage + " damage.";
	  }

	  	/**
	  	 * Returns the special menu string for Squirtle
	  	 * @return the specialMenu string from the Water interface
	  	 */
		@Override
		String getSpecialMenu() {
			return Water.specialMenu;
		}
		
		/**
	  	 * Returns the number of special attacks by Squirtle
	  	 * @return the number of special attacks as an integer
	  	 */
		@Override
		int getNumSpecialMenuItems() {
			return Water.numSpecialMenuItems;
		}
		
		/**
	  	 * Returns the special attacks battle description
	  	 * @param p is the opposing pokemon
	  	 * @param move is the special attack choice by the user
	  	 * @return the string that contains the battle description using special attacks
	  	 */
		@Override
		String specialAttack(Pokemon p, int move) {
			String battleDescription = "";
			
			// wild pokemon is passed through the parameter and is attacked based on the move choice of the user
			switch(move)	{
				case 1: battleDescription += waterGun(p);
						break;
				case 2: battleDescription += bubbleBeam(p);
						break;
				case 3: battleDescription += waterfall(p);
						break;
			}
			return battleDescription;
		}
}
