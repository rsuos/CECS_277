/**
 * Interface to be used by Pokemons of type Water. Integer 1 on battle table
 */
interface Water {
  
  /**
  * Displays the special attack menu and has the player choose an attack
  */
	public String specialMenu = "1. Water Gun \n2. Bubble Beam\n3. Waterfall";

  /**
  * Returns the number of Special Menu Items as an integer
  */
	public int numSpecialMenuItems = 3;

  /**
  * Method for Water type Pokemons to implement Water Gun in their class 
  */
	public String waterGun(Pokemon p);

  /**
  * Method for Water type Pokemons to implement Bubble Beam in their class
  */
	public String bubbleBeam(Pokemon p);

  /**
  * Method for Water type Pokemons to implement Waterfall in their class 
  */
	public String waterfall(Pokemon p);
}
