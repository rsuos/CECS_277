// Done by Ryan

/**
 * Interface to be used by Pokemons of type Grass. Integer 2 on battle table
 */
public interface Grass
{
  /**
  * Displays the special attack menu and has the player choose an attack
  */
  public String specialMenu ="1. Vine Whip\n2. Razor Leaf\n3. Solar Beam";

  /**
  * Returns the number of Special Menu Items as an integer
  */
  int numSpecialMenuItems = 3;

  /**
  * Method for Grass type Pokemons to implement vineWhip in their class 
  */
  public String vineWhip(Pokemon p);

  /**
  * Method for Grass type Pokemons to implement razorLeaf in their class 
  */
  public String razorLeaf(Pokemon p);

  /**
  * Method for Grass type Pokemons to implement solarBeam in their class 
  */
  public String solarBeam(Pokemon p);

}