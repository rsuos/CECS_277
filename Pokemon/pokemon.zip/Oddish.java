import java.util.Random;

/**
 * Oddish is a grass type pokemon that inherits the Pokemon class and extends the Grass interface
 */
public class Oddish extends Pokemon implements Grass
{
  /**
   * Default constructor for Oddish
   */
  public Oddish()
  {
    super("Oddish");
  }
  
  /**
   * Retrieves the special menu from the Grass interface
   */
  @Override
  public String getSpecialMenu()
  {
    return Grass.specialMenu;
  }
  
  /**
   * Retrieves the number of special menu items
   */
  @Override
  public int getNumSpecialMenuItems()
  {
	  return Grass.numSpecialMenuItems;
  }
  
  /**
   * Performs the special attacks for grass types
   * @param p is the opposing pokemon
   * @param move is the move option chosen by the user
   * @return battleDescription is a description of the battle between the two pokemon
   */
  @Override
  public String specialAttack(Pokemon p, int move)
  {
	  String battleDescription = "";
	  
	  switch (move)
	  {
	  case 1:
		  battleDescription += vineWhip(p);
		  break;
	case 2: 
		  battleDescription += razorLeaf(p);
		  break;
	case 3:
		  battleDescription += solarBeam(p);
		  break;
	  }
	  
	  return battleDescription;
  }

  /**
   * First attack of grass types
   * @param p is the opposing pokemon
   * @return is the battle description using Vine Whip 
   */
  @Override
  public String vineWhip(Pokemon p)
  {
	  // 1 - 3 Damage
	  Random r = new Random();
	  int battleDamage = r.nextInt(3) + 1;
	  double typeMatchUp = battleTable[this.getType()][p.getType()];
	  int totalDamage = (int)(typeMatchUp * battleDamage);
	  p.takeDamage(totalDamage);
	   
	  return p.getName() + " is repeatedly lashed with WHIPS made of VINE and takes " + totalDamage + " damage.";
  }

  /**
   * Second attack of grass types
   * @param p is the opposing pokemon
   * @return is the battle description using Razor Leaf
   */
  @Override
  public String razorLeaf(Pokemon p)
  {

	  // 2 - 4 Damage
	  Random r = new Random();
	  int battleDamage = r.nextInt(3) + 2;
	  double typeMatchUp = battleTable[this.getType()][p.getType()];
	  int totalDamage = (int)(typeMatchUp * battleDamage);
	  p.takeDamage(totalDamage);
	  
	  return p.getName() + " is lacerated with sharp RAZOR LEAVES and takes " + totalDamage + " damage.";
  }

  /**
   * Third attack of grass types
   * @param p is the opposing pokemon
   * @return is the battle description using Solar Beam
   */
  @Override
  public String solarBeam(Pokemon p)
  {
	  // 0 - 3 Damage
	  Random r = new Random();
	  int battleDamage = r.nextInt(3);
	  double typeMatchUp = battleTable[this.getType()][p.getType()];
	  int totalDamage = (int)(typeMatchUp * battleDamage);
	  p.takeDamage(totalDamage);
	  
	  return p.getName() + " is overwhelmed by a bright SOLAR BEAM and takes " + totalDamage + " damage.";
  }
}