/**
 * Interface to be used by Pokemons of type Fire. Integer 0 on battle table
 */
interface Fire  {
  /**
  * Displays the special attack menu and has the player choose an attack
  */
  public String specialMenu = "1. Ember \n2. Fire Blast\n3. Fire Punch";
  
  /**
  * Returns the number of Special Menu Items as an integer
  */
  public int numSpecialMenuItems = 3;

  /**
  * Method for Fire type Pokemons to implement Ember in their class 
  */
  public String ember(Pokemon p);

  /**
  * Method for Fire type Pokemons to implement fireBlast in their class 
  */
  public String fireBlast(Pokemon p);

  /**
  * Method for Fire type Pokemons to implement firePunch in their class 
  */
  public String firePunch(Pokemon p);
}